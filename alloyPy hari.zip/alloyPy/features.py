import json
import pandas as pd
import numpy as np

import importlib.resources 

class FeatureGenerator:
    def __init__(self):
        # Load data from JSON
        #with importlib.resources.files('alloyPy.data').joinpath('elementalData.json').open('r') as jsonFile:
        #    self.elemental_data = json.load(jsonFile)
        with importlib.resources.open_text('alloyPy.data', 'elementalData.json') as jsonFile:
            self.elemental_data = json.load(jsonFile)
        with importlib.resources.open_text('alloyPy.data', 'binaryEnthalpyData.json') as jsonFile:
            self.binary_enthalpies = json.load(jsonFile)
        print("alloyPy 0.0.1 : FeatureGenerator() Initialization successful")
        pass


    def getFeatures(self, featureNames, elements, composition):
        """
        Return the specified set of metallurgically-informed properties for a given set of alloy compositions

        Keyword arguments:
        featureNames: A list of strings indicating the properties which are to be calculated.
        'all' indicates that all available properties should be calculated.
        As of now, the avilable properties are: 'mixing_enthalpy', 'configurational_entropy', 'composition_mean_atomicSize', 'weighted_atomicSize_rmsVariation','pairwise_atomicSize_mismatch', 'lambda_parameter',
        'weighted_electronegativity_rmsDeviation', 'pairwise_electronegativity_mismatch', 'composition_mean_vec', 'workFunction_parameter', 'composition_mean_cohesiveEnergy',
        'composition_mean_shearModulus', 'weighted_shearModulus_rmsVariation', 'strengthening_energy_term', 'peierls_nabarro_factor'
        elements: a list of elements 
        composition:
        """
        elementalRadii = np.array([ self.elemental_data[element]["radius"] for element in elements ])

        elementalElectronegativities = np.array([ self.elemental_data[element]["electronegativity"] for element in elements ])

        elementalValanceElectronNumbers = np.array([ self.elemental_data[element]["valence_electron_number"] for element in elements ])

        elementalCohesiveEnergies = np.array([ self.elemental_data[element]["cohesive_energy"] for element in elements ])

        elementalShearModuli = np.array([ self.elemental_data[element]["shear_modulus"] for element in elements ])
        
        elementalPossionsRatios = np.array([ self.elemental_data[element]["poissons_ratio"] for element in elements ])

        elementalWorkFunctions = np.array([ self.elemental_data[element]["work_function"] for element in elements ])
        
        #binaryEnthalpies = { element: self.binary_enthalpies[element] for element in elements }
        binaryEnthalpies = np.array([[self.binary_enthalpies[element1][element2] for element1 in elements] for element2 in elements])
        


        # Convert composition to a DataFrame if it's a NumPy array
        if isinstance(composition, np.ndarray):
            composition = pd.DataFrame(composition, columns=elements)

        # Calculate the specified functions for each composition
        # TODO Convert to apply() https://stackoverflow.com/questions/14529838/apply-multiple-functions-to-multiple-groupby-columns
        featureData_allAlloys = [] # See https://stackoverflow.com/a/56746204
        for index, row in composition.iterrows():
            featureData = []
            getAll = False
            if 'all' in featureNames:
                getAll = True
                featureNames = ['mixing_enthalpy', 'configurational_entropy',
                                'composition_mean_atomicSize', 'weighted_atomicSize_rmsVariation','pairwise_atomicSize_mismatch', 'lambda_parameter',
                                 'weighted_electronegativity_rmsDeviation', 'pairwise_electronegativity_mismatch',
                                'composition_mean_vec', 
                                'workFunction_parameter', 'composition_mean_cohesiveEnergy',
                                'composition_mean_shearModulus', 'weighted_shearModulus_rmsVariation', 'pairwise_vec_mismatch',
                                'strengthening_energy_term', 'peierls_nabarro_factor']
            for func_name in featureNames:
                if func_name == 'mixing_enthalpy':
                    featureData.append( self.getMixingEnthalphy(row, binaryEnthalpies) )
                elif func_name == 'configurational_entropy':
                    featureData.append( self.getConfigurationalEntropy(row) )
                    
                elif func_name == 'composition_mean_atomicSize':
                    featureData.append( self.getMeanAtomicSize(row, elementalRadii) )
                elif func_name == 'weighted_atomicSize_rmsVariation':
                    featureData.append( self.getAtomicSizeMismatch(row, elementalRadii) )
                elif func_name == 'pairwise_atomicSize_mismatch':
                    featureData.append( self.getLocalSizeMismatch(row, elementalRadii) )
                elif func_name == 'lambda_parameter':
                    featureData.append( self.getLambdaParameter(row, elementalRadii) )
                
                elif func_name == 'composition_mean_electronegativity':
                    featureData.append( self.getMeanElectronegativity(row, elementalElectronegativities) )
                elif func_name == 'weighted_electronegativity_rmsDeviation':
                    featureData.append( self.getRMSElectronegativityDifference(row, elementalElectronegativities) )
                elif func_name == 'pairwise_electronegativity_mismatch':
                    featureData.append( self.getLocalElectronegativityMismatch(row, elementalElectronegativities) )
                    
                elif func_name == 'composition_mean_vec':                    
                    featureData.append( self.getMeanVEC(row, elementalValanceElectronNumbers) )
                elif func_name == 'weighted_vec_rmsDeviation':
                    featureData.append( self.getRMSVECDifference(row, elementalValanceElectronNumbers) )
                elif func_name == 'pairwise_vec_mismatch':
                    featureData.append( self.getLocalVECMismatch(row, elementalValanceElectronNumbers) )
                    
                elif func_name == 'workFunction_parameter':
                    featureData.append( self.getWorkFunctionParameter(row, elementalWorkFunctions) )
                elif func_name == 'composition_mean_cohesiveEnergy':
                    featureData.append( self.getMeanCohesiveEnergy(row, elementalCohesiveEnergies) )
                    
                elif func_name == 'composition_mean_shearModulus':
                    featureData.append( self.getMeanShearModulus(row, elementalShearModuli) )
                elif func_name == 'weighted_shearModulus_rmsVariation':
                    featureData.append( self.getModulusMismatch(row, elementalShearModuli) )
                    
                elif func_name == 'strengthening_energy_term':
                    featureData.append( self.getStrengtheningEnergy(row, elementalShearModuli, elementalPossionsRatios, elementalRadii) )
                elif func_name == 'peierls_nabarro_factor':
                    featureData.append( self.getPeierlsNabarroFactor(row, elementalShearModuli, elementalPossionsRatios) )
            featureData_allAlloys.append(featureData)
            result_df = pd.DataFrame(featureData_allAlloys, columns=featureNames)

        return result_df

 
    def getMixingEnthalphy(self, composition, binaryEnthalpiesOfMixing): # ΔH
        mixingEnthalphy = 0
        for i, ci in enumerate(composition.values):
            for j in range(i+1, composition.shape[0]):
                mixingEnthalphy += 4 * ci * composition.values[j] * binaryEnthalpiesOfMixing[i, j]
        return mixingEnthalphy

    def getConfigurationalEntropy(self, composition): # ΔS
        return  np.sum( (-8.314 *  composition * np.log(composition + 1e-20)).values )
    
    def getMeanAtomicSize(self, composition, elementalRadii):
        return np.sum(composition * elementalRadii)

    def getAtomicSizeMismatch(self, composition, elementalRadii): # δr
        composition = composition.values

        weightedMeanAtomicRadius = np.sum(composition * elementalRadii)

        atomicMismatches = 1 - (elementalRadii / weightedMeanAtomicRadius)

        return np.sqrt(np.sum(composition * (atomicMismatches**2)))

    def getLocalSizeMismatch(self, composition, elementalRadii):
        #composition = composition.values[0]
        mismatch = 0
        for i, ci in enumerate(composition):
            for j, cj in enumerate(composition):
                mismatch += ci * cj * np.abs((elementalRadii[i] - elementalRadii[j]))
        return mismatch

    def getLambdaParameter(self, composition, elementalRadii):  # Λ
        configurationalEntropy = self.getConfigurationalEntropy(composition)
        atomicSizeMismatch = self.getAtomicSizeMismatch(composition, elementalRadii)

        return configurationalEntropy / (atomicSizeMismatch**2)
    
    def getMeanElectronegativity(self, composition, elementalElectronegativities):
        return np.sum(composition * Electronegativities)

    def getRMSElectronegativityDifference(self, composition, elementalElectronegativities): # Δχ
        weightedMeanElectronegativity = np.sum(composition * elementalElectronegativities)

        electronegativityDifferences = elementalElectronegativities - weightedMeanElectronegativity

        return np.sqrt(np.sum(composition * (electronegativityDifferences)**2))

    def getLocalElectronegativityMismatch(self, composition, elementalElectronegativities):
        #composition = composition.values[0]
        mismatch = 0
        for i, ci in enumerate(composition):
            for j, cj in enumerate(composition):
                mismatch += ci * cj * np.abs((elementalElectronegativities[i] - elementalElectronegativities[j]))
        return mismatch

    def getMeanVEC(self, composition, elementalValanceElectronNumbers): # VEC
        return np.sum(composition * elementalValanceElectronNumbers)
    
    def getRMSVECDifference(self, composition, elementalValanceElectronNumbers): # Δχ
        weightedMeanVEC = np.sum(composition * elementalValanceElectronNumbers)

        vecDifferences = elementalValanceElectronNumbers - weightedMeanVEC

        return np.sqrt(np.sum(composition * (vecDifferences)**2))

    def getLocalVECMismatch(self, composition, elementalValanceElectronNumbers):
        #composition = composition.values[0]
        mismatch = 0
        for i, ci in enumerate(composition):
            for j, cj in enumerate(composition):
                mismatch += ci * cj * np.abs((elementalValanceElectronNumbers[i] - elementalValanceElectronNumbers[j]))
        return mismatch

    def getWorkFunctionParameter(self, composition, elementalWorkFunctions): # w
        meanWorkFunction = np.sum(composition.values * elementalWorkFunctions)
        return meanWorkFunction**6

    def getMeanCohesiveEnergy(self, composition, elementalCohesiveEnergies): # Ec
        return np.sum(composition.values * elementalCohesiveEnergies)

    def getMeanShearModulus(self, composition, elementalShearModuli): # G
        return np.sum(composition.values * elementalShearModuli)

    def getModulusMismatch(self, composition, elementalShearModuli): # η
        meanShearModulus = self.getMeanShearModulus(composition, elementalShearModuli)

        mismatchFactors = 2 * (composition.values * (elementalShearModuli - meanShearModulus) / (elementalShearModuli + meanShearModulus))

        modulusMismatch = np.sum(mismatchFactors / (1 + 0.5 * np.abs(mismatchFactors)))

        return modulusMismatch

    def getStrengtheningEnergy(self, composition, elementalShearModuli, elementalPossionsRatios, elementalRadii): # A
        meanShearModulus = self.getMeanShearModulus(composition, elementalShearModuli)
        meanPoissonsRatio = np.sum(composition.values * elementalPossionsRatios)
        atomicSizeMismatch = self.getAtomicSizeMismatch(composition, elementalRadii)

        return meanShearModulus * atomicSizeMismatch * (1 + meanPoissonsRatio) / (1 - meanPoissonsRatio)

    def getPeierlsNabarroFactor(self, composition, elementalShearModuli, elementalPossionsRatios): # F
        meanShearModulus = self.getMeanShearModulus(composition, elementalShearModuli)
        meanPoissonsRatio = np.sum(composition.values * elementalPossionsRatios)
        return 2 * meanShearModulus / (1 - meanPoissonsRatio)